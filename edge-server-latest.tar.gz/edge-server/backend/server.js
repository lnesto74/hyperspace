import express from 'express';
import cors from 'cors';
import mqtt from 'mqtt';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import net from 'net';
import crypto from 'crypto';
import dgram from 'dgram';
import http from 'http';
import { WebSocketServer } from 'ws';
import { listenForDifop, probeRoboSense, setLidarIpViaHttp, getLidarConfigViaHttp } from './robosense-commissioner.js';
import { capturePointCloudSnapshot, pointsToBuffer, pointsToPly, startPointCloudStream } from './robosense-pointcloud.js';

// V2 Simulation modules
import { SimulatorV2, SIM_CONFIG, STATE } from './sim/index.js';

// HER (Hyperspace Edge Runtime) Manager
import { initHerManager, deployHer, stopHer, getHerStatus, getMode, isHerActive } from './her-manager.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend files
app.use(express.static(join(__dirname, '../frontend/dist')));

// Use data folder for persistent storage (mounted as Docker volume)
const DATA_DIR = join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const CONFIG_FILE = join(DATA_DIR, 'config.json');

// Default configuration
const defaultConfig = {
  mqttBroker: 'mqtt://localhost:1883',
  backendUrl: 'http://localhost:3001',
  deviceId: 'lidar-edge-001',
  venueId: 'default-venue',
  frequencyHz: 10,
  personCount: 5,
  targetPeopleCount: 20, // Target number of people in scene at any time
  avgStayTime: 5, // Average stay time in minutes
  venueWidth: 20,
  venueDepth: 15,
  simulationMode: 'random', // 'random', 'queue', 'mixed'
  queueSpawnInterval: 5, // seconds between new queue customers
  useSimV2: true, // Feature flag: use new V2 simulation with navgrid, pathfinding, anti-glitch
  // Cashier agent settings
  enableCashiers: true,
  cashierShiftMin: 60, // Average shift duration in minutes
  cashierBreakProb: 15, // Break probability per hour (%)
  laneOpenConfirmSec: 120, // Seconds cashier must be present before lane marked open
  enableIdConfusion: false, // Simulate LiDAR ID tracking errors
  // Checkout Manager settings
  enableCheckoutManager: false, // Manual lane control (false = auto cashier scheduling)
  queuePressureThreshold: 5, // Suggest opening lane when avg queue > this
  // Queue Pressure Controls (for KPI-driven simulation)
  checkoutProbMultiplier: 1.0, // Multiplier for checkout probability (1.0 = default, 2.0 = double checkout rate)
  browsingSpeedMultiplier: 1.0, // Multiplier for browsing speed (1.0 = default, 2.0 = finish browsing 2x faster)
  arrivalRateMultiplier: 1.0, // Multiplier for arrival rate (1.0 = default, 2.0 = double arrivals)
  // Wait time thresholds (minutes) for queue visualization colors
  waitTimeWarningMin: 2, // Green -> Orange threshold
  waitTimeCriticalMin: 5, // Orange -> Red threshold
};

// SimulatorV2 instance
let simulatorV2 = null;

// Load config from file or use defaults
let config = { ...defaultConfig };
try {
  if (fs.existsSync(CONFIG_FILE)) {
    config = { ...defaultConfig, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8')) };
  }
} catch (err) {
  console.error('Failed to load config:', err.message);
}

// Save config to file
const saveConfig = () => {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
  } catch (err) {
    console.error('Failed to save config:', err.message);
  }
};

// Simulation state
let isRunning = false;
let mqttClient = null;
let simulationInterval = null;
let people = [];
let stats = {
  tracksSent: 0,
  startTime: null,
  lastError: null,
  mqttConnected: false,
};

// Venue geometry (fetched from backend)
let venueGeometry = null;
let cashierZones = [];
let entranceObjects = []; // Entrance objects for spawning

const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

// Fetch venue geometry from Hyperspace backend
const fetchVenueGeometry = async () => {
  try {
    console.log(`Fetching geometry from ${config.backendUrl}/api/venues/${config.venueId}`);
    
    const venueRes = await fetch(`${config.backendUrl}/api/venues/${config.venueId}`);
    if (!venueRes.ok) {
      console.error('Failed to fetch venue:', venueRes.status);
      return null;
    }
    const venueData = await venueRes.json();
    
    // Check if venue has a DWG layout - if so, fetch DWG ROIs instead of manual ROIs
    const dwgLayoutId = venueData.venue?.dwg_layout_version_id;
    let roiUrl;
    if (dwgLayoutId) {
      roiUrl = `${config.backendUrl}/api/venues/${config.venueId}/dwg/${dwgLayoutId}/roi`;
      console.log(`Venue has DWG layout: ${dwgLayoutId}, fetching DWG ROIs`);
    } else {
      roiUrl = `${config.backendUrl}/api/venues/${config.venueId}/roi`;
      console.log(`Venue has no DWG layout, fetching manual ROIs`);
    }
    
    const roiRes = await fetch(roiUrl);
    if (!roiRes.ok) {
      console.error('Failed to fetch ROIs:', roiRes.status);
      return null;
    }
    const rois = await roiRes.json();
    
    console.log(`Loaded venue: ${venueData.venue?.name}, ${rois.length} ROIs`);
    return { venue: venueData.venue, objects: venueData.objects || [], rois };
  } catch (err) {
    console.error('Error fetching geometry:', err.message);
    return null;
  }
};

// Calculate zone center from vertices
const calculateZoneCenter = (vertices) => {
  if (!vertices || vertices.length === 0) return { x: 0, z: 0 };
  const sum = vertices.reduce((acc, v) => ({ x: acc.x + v.x, z: acc.z + v.z }), { x: 0, z: 0 });
  return { x: sum.x / vertices.length, z: sum.z / vertices.length };
};

// Store obstacles (venue objects that agents should avoid)
let obstacles = [];
const OBSTACLE_PADDING = 0.2; // 20cm minimum distance from objects

// Parse venue objects into obstacle boundaries
const parseObstacles = (geometry) => {
  const obs = [];
  const objects = geometry.objects || [];
  
  for (const obj of objects) {
    if (!obj.position) continue;
    
    // Get object dimensions (default to 1x1 if not specified)
    const width = obj.scale?.x || obj.width || 1;
    const depth = obj.scale?.z || obj.depth || 1;
    const rotation = obj.rotation?.y || 0;
    
    // Calculate bounding box with padding
    const halfW = (width / 2) + OBSTACLE_PADDING;
    const halfD = (depth / 2) + OBSTACLE_PADDING;
    
    // For rotated objects, use the larger dimension for a conservative bounding box
    const cosR = Math.abs(Math.cos(rotation));
    const sinR = Math.abs(Math.sin(rotation));
    const effectiveHalfW = halfW * cosR + halfD * sinR;
    const effectiveHalfD = halfW * sinR + halfD * cosR;
    
    obs.push({
      name: obj.name || 'object',
      x: obj.position.x,
      z: obj.position.z,
      minX: obj.position.x - effectiveHalfW,
      maxX: obj.position.x + effectiveHalfW,
      minZ: obj.position.z - effectiveHalfD,
      maxZ: obj.position.z + effectiveHalfD,
      radius: Math.max(effectiveHalfW, effectiveHalfD), // For circular collision
    });
  }
  
  console.log(`Parsed ${obs.length} obstacles for collision avoidance`);
  return obs;
};

// Parse entrance objects from venue geometry
const parseEntrances = (geometry) => {
  const entrances = [];
  const objects = geometry.objects || [];
  
  for (const obj of objects) {
    if (!obj.position) continue;
    
    // Check if object is an entrance (by name or type)
    const name = (obj.name || '').toLowerCase();
    const type = (obj.type || '').toLowerCase();
    
    if (name.includes('entrance') || name.includes('entry') || name.includes('door') || 
        type.includes('entrance') || type === 'door') {
      const width = obj.scale?.x || obj.width || 2;
      const depth = obj.scale?.z || obj.depth || 1;
      
      entrances.push({
        name: obj.name || 'entrance',
        x: obj.position.x,
        z: obj.position.z,
        width,
        depth,
        // Calculate spawn area around entrance
        minX: obj.position.x - width / 2,
        maxX: obj.position.x + width / 2,
        minZ: obj.position.z - depth / 2,
        maxZ: obj.position.z + depth / 2,
      });
    }
  }
  
  console.log(`Parsed ${entrances.length} entrance objects for spawning`);
  return entrances;
};

// Get a random spawn position from an entrance
const getEntranceSpawnPosition = () => {
  if (entranceObjects.length === 0) {
    // Fallback: spawn at edge of venue if no entrances defined
    return {
      x: config.venueWidth * (0.1 + Math.random() * 0.8),
      z: config.venueDepth - 0.5,
      entrance: null
    };
  }
  
  // Pick a random entrance
  const entrance = entranceObjects[Math.floor(Math.random() * entranceObjects.length)];
  
  // Spawn at random position within entrance area
  return {
    x: entrance.minX + Math.random() * entrance.width,
    z: entrance.minZ + Math.random() * entrance.depth,
    entrance
  };
};

// Check if a point is inside any obstacle
const isInsideObstacle = (x, z) => {
  for (const obs of obstacles) {
    if (x >= obs.minX && x <= obs.maxX && z >= obs.minZ && z <= obs.maxZ) {
      return obs;
    }
  }
  return null;
};

// Check if a position collides with any obstacle (simplified - just center point)
const checkCollision = (x, z) => {
  return isInsideObstacle(x, z);
};

// Get soft avoidance force from nearby obstacles
const getAvoidanceForce = (x, z) => {
  let forceX = 0;
  let forceZ = 0;
  const avoidanceRadius = 0.6; // Start avoiding at 60cm
  
  for (const obs of obstacles) {
    const dx = x - obs.x;
    const dz = z - obs.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    
    // Soft avoidance - just nudge away from obstacle centers
    if (dist < obs.radius + avoidanceRadius && dist > 0.01) {
      const strength = 1 - (dist / (obs.radius + avoidanceRadius));
      forceX += (dx / dist) * strength * 1.5;
      forceZ += (dz / dist) * strength * 1.5;
    }
  }
  
  return { x: forceX, z: forceZ };
};

// Find a valid position that's not inside an obstacle
const findValidPosition = (x, z, venueWidth, venueDepth) => {
  // If current position is valid, return it
  if (!isInsideObstacle(x, z)) return { x, z };
  
  // Try random positions nearby
  for (let i = 0; i < 20; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = 1 + Math.random() * 2;
    const newX = Math.max(0.5, Math.min(venueWidth - 0.5, x + Math.cos(angle) * dist));
    const newZ = Math.max(0.5, Math.min(venueDepth - 0.5, z + Math.sin(angle) * dist));
    if (!isInsideObstacle(newX, newZ)) return { x: newX, z: newZ };
  }
  
  // Fallback: return original position
  return { x, z };
};

// Parse cashier zones from ROIs
// Returns array sorted by X position with queueZoneId (UUID) as primary identifier
// Pairs Queue/Service zones by matching name prefix (e.g., "Checkout 1 - Queue" <-> "Checkout 1 - Service")
const parseCashierZones = (geometry) => {
  const zones = [];
  const rois = geometry.rois || [];
  
  const queueZones = rois.filter(r => r.name && r.name.endsWith('- Queue'));
  const serviceZones = rois.filter(r => r.name && r.name.endsWith('- Service'));
  
  console.log(`Found ${queueZones.length} queue zones, ${serviceZones.length} service zones`);
  
  for (const queueZone of queueZones) {
    // Extract prefix: "Checkout 1 - Queue" -> "Checkout 1"
    const cashierName = queueZone.name.replace('- Queue', '').trim();
    const serviceZone = serviceZones.find(s => s.name.replace('- Service', '').trim() === cashierName);
    
    const queueCenter = calculateZoneCenter(queueZone.vertices);
    
    if (serviceZone) {
      const serviceCenter = calculateZoneCenter(serviceZone.vertices);
      
      zones.push({
        name: cashierName,
        queueZoneId: queueZone.id,       // UUID - the single source of truth
        serviceZoneId: serviceZone.id,   // UUID
        queueZone: { ...queueZone, center: queueCenter },
        serviceZone: { ...serviceZone, center: serviceCenter },
        queueCenter,
        serviceCenter,
      });
      console.log(`Paired: ${cashierName} (queue: ${queueZone.id.substring(0,8)})`);
    } else {
      // No matching service zone - still create lane with just queue zone
      zones.push({
        name: cashierName,
        queueZoneId: queueZone.id,
        serviceZoneId: null,
        queueZone: { ...queueZone, center: queueCenter },
        serviceZone: null,
        queueCenter,
        serviceCenter: queueCenter,  // Use queue center as fallback
      });
      console.log(`Queue zone only (no matching service): ${cashierName} (${queueZone.id.substring(0,8)})`);
    }
  }
  
  // Sort by X position for consistent Lane 1, 2, 3 numbering
  zones.sort((a, b) => (a.queueCenter?.x || 0) - (b.queueCenter?.x || 0));
  
  // Assign display index (1-indexed)
  zones.forEach((z, i) => {
    z.displayIndex = i + 1;
    z.displayName = `Lane ${i + 1}`;
  });
  
  return zones;
};

// Store cashier gap boundaries (one-way zones)
let cashierGapZones = [];

// Parse cashier gaps from service zones (these are one-way: exit only)
const parseCashierGaps = (geometry) => {
  const gaps = [];
  const rois = geometry.rois || [];
  const serviceZones = rois.filter(r => r.name.endsWith('- Service'));
  
  for (const zone of serviceZones) {
    if (zone.vertices && zone.vertices.length >= 3) {
      const minX = Math.min(...zone.vertices.map(v => v.x));
      const maxX = Math.max(...zone.vertices.map(v => v.x));
      const minZ = Math.min(...zone.vertices.map(v => v.z));
      const maxZ = Math.max(...zone.vertices.map(v => v.z));
      gaps.push({ minX, maxX, minZ, maxZ, name: zone.name });
    }
  }
  console.log(`Parsed ${gaps.length} cashier gaps (one-way exit zones)`);
  return gaps;
};

// Check if position is in a cashier gap (exit-only zone)
const isInCashierGap = (x, z) => {
  for (const gap of cashierGapZones) {
    if (x >= gap.minX && x <= gap.maxX && z >= gap.minZ && z <= gap.maxZ) {
      return true;
    }
  }
  return false;
};

class Person {
  constructor(id, venueWidth, venueDepth, spawnDelay = 0) {
    this.id = id;
    this.venueWidth = venueWidth;
    this.venueDepth = venueDepth;
    
    // Spawn delay for staggered entry
    this.spawnDelay = spawnDelay;
    this.spawned = spawnDelay === 0;
    this.spawnTimer = 0;
    
    // Get spawn position from entrance object
    const spawnPos = getEntranceSpawnPosition();
    this.entranceX = spawnPos.x;
    this.entranceZ = spawnPos.z;
    this.spawnEntrance = spawnPos.entrance; // Store which entrance we spawned from
    
    // Start at entrance (or off-screen if delayed)
    this.x = this.spawned ? this.entranceX : -10;
    this.z = this.spawned ? this.entranceZ : -10;
    
    // Calculate target stay time based on config (with some variance)
    const baseStayTime = config.avgStayTime * 60; // Convert minutes to seconds
    this.targetStayTime = baseStayTime * (0.5 + Math.random()); // 50%-150% of avg
    
    // Generate waypoints based on stay time
    this.waypoints = this.generateWaypoints();
    this.currentWaypointIndex = 0;
    this.targetX = this.waypoints[0].x;
    this.targetZ = this.waypoints[0].z;
    
    // Movement properties
    this.baseSpeed = 0.8 + Math.random() * 0.4; // 0.8-1.2 m/s walking speed
    this.speed = this.baseSpeed;
    this.color = COLORS[id % COLORS.length];
    this.width = 0.4 + Math.random() * 0.2;
    this.height = 1.5 + Math.random() * 0.4;
    this.vx = 0;
    this.vz = 0;
    
    // Wobble for natural movement
    this.wobblePhase = Math.random() * Math.PI * 2;
    this.wobbleFreq = 1.5 + Math.random() * 1; // How fast they wobble
    this.wobbleAmount = 0.1 + Math.random() * 0.1; // How much they wobble
    
    // Stopping behavior
    this.isStopped = false;
    this.stopTimer = 0;
    this.stopDuration = 0;
    this.timeSinceLastStop = 0;
    this.nextStopTime = 10 + Math.random() * 30; // Stop every 10-40 seconds
    
    // Track total time and if done
    this.totalTime = 0;
    this.done = false;
    this.returning = false;
  }

  generateWaypoints() {
    const waypoints = [];
    
    // STORE LAYOUT CONSTANTS (based on actual venue geometry)
    const CASHIER_LINE_Z = 7;        // Cashiers are at z=7
    const SHOPPING_MIN_Z = 15;       // Shopping area starts at z=15
    const SHOPPING_MAX_Z = 32;       // Shopping area ends at z=32
    const SHOPPING_MIN_X = 8;        // Shopping area x range
    const SHOPPING_MAX_X = 28;
    const BYPASS_X = this.venueWidth - 2; // Right side bypass corridor (x=38)
    
    // PHASE 1: ENTRY - Walk around cashiers on the right side
    // From entrance, go right along front, then up past cashier line
    waypoints.push({ x: BYPASS_X, z: 3 });           // Walk right along front
    waypoints.push({ x: BYPASS_X, z: SHOPPING_MIN_Z }); // Walk up past cashiers
    
    // PHASE 2: SHOPPING - Generate waypoints in shopping area
    const targetWaypoints = Math.max(3, Math.floor(this.targetStayTime / 30));
    const shoppingWaypoints = Math.min(8, Math.max(2, targetWaypoints - 2));
    
    for (let i = 0; i < shoppingWaypoints; i++) {
      const wx = SHOPPING_MIN_X + Math.random() * (SHOPPING_MAX_X - SHOPPING_MIN_X);
      const wz = SHOPPING_MIN_Z + Math.random() * (SHOPPING_MAX_Z - SHOPPING_MIN_Z);
      const valid = findValidPosition(wx, wz, this.venueWidth, this.venueDepth);
      waypoints.push({ x: valid.x, z: valid.z });
    }
    
    // PHASE 3: EXIT - Go to queue, through cashier, back to entrance
    // Pick a random cashier x position for checkout
    const cashierXPositions = [9, 12, 15, 18, 21, 25, 28, 31, 34];
    const selectedCashierX = cashierXPositions[Math.floor(Math.random() * cashierXPositions.length)];
    
    // Approach queue area (just behind cashier)
    waypoints.push({ x: selectedCashierX, z: CASHIER_LINE_Z + 5 }); // Queue position
    waypoints.push({ x: selectedCashierX, z: CASHIER_LINE_Z });     // At cashier
    waypoints.push({ x: selectedCashierX, z: 3 });                   // Past cashier gap
    
    // Return to entrance (same as entry point)
    waypoints.push({ x: this.entranceX, z: this.entranceZ });
    
    return waypoints;
  }

  update(dt) {
    if (this.done) return false;
    
    // Handle spawn delay (staggered entry)
    if (!this.spawned) {
      this.spawnTimer += dt;
      if (this.spawnTimer >= this.spawnDelay) {
        this.spawned = true;
        this.x = this.entranceX;
        this.z = this.entranceZ;
      } else {
        return true; // Still waiting to spawn
      }
    }
    
    this.totalTime += dt;
    this.timeSinceLastStop += dt;
    
    // Check if should start stopping
    if (!this.isStopped && !this.returning && this.timeSinceLastStop > this.nextStopTime) {
      this.isStopped = true;
      this.stopDuration = 3 + Math.random() * 7; // Stop for 3-10 seconds
      this.stopTimer = 0;
      this.vx = 0;
      this.vz = 0;
    }
    
    // Handle stopped state
    if (this.isStopped) {
      this.stopTimer += dt;
      if (this.stopTimer >= this.stopDuration) {
        this.isStopped = false;
        this.timeSinceLastStop = 0;
        this.nextStopTime = 15 + Math.random() * 30;
      }
      // Small idle movement while stopped
      this.vx = (Math.random() - 0.5) * 0.05;
      this.vz = (Math.random() - 0.5) * 0.05;
      return true;
    }
    
    const dx = this.targetX - this.x;
    const dz = this.targetZ - this.z;
    const dist = Math.sqrt(dx * dx + dz * dz);

    if (dist < 0.5) {
      // Reached waypoint
      this.currentWaypointIndex++;
      
      if (this.currentWaypointIndex >= this.waypoints.length) {
        // Completed path, person exits
        this.done = true;
        return false;
      }
      
      // Check if this is the return waypoint
      if (this.currentWaypointIndex === this.waypoints.length - 1) {
        this.returning = true;
      }
      
      this.targetX = this.waypoints[this.currentWaypointIndex].x;
      this.targetZ = this.waypoints[this.currentWaypointIndex].z;
      this.speed = this.baseSpeed * (0.8 + Math.random() * 0.4);
    } else {
      // Update wobble phase
      this.wobblePhase += this.wobbleFreq * dt;
      
      // Base direction toward target
      const dirX = dx / dist;
      const dirZ = dz / dist;
      
      // Perpendicular direction for wobble
      const perpX = -dirZ;
      const perpZ = dirX;
      
      // Add sinusoidal wobble
      const wobble = Math.sin(this.wobblePhase) * this.wobbleAmount;
      
      // Base velocity with wobble
      let vx = (dirX + perpX * wobble) * this.speed;
      let vz = (dirZ + perpZ * wobble) * this.speed;
      
      // Add soft avoidance force from obstacles
      const avoidance = getAvoidanceForce(this.x, this.z);
      vx += avoidance.x * this.speed;
      vz += avoidance.z * this.speed;
      
      // Calculate new position
      let newX = this.x + vx * dt;
      let newZ = this.z + vz * dt;
      
      // Simple collision check - if inside obstacle, try to slide around
      const obstacle = checkCollision(newX, newZ);
      if (obstacle) {
        // Try sliding along X axis only
        if (!checkCollision(newX, this.z)) {
          newZ = this.z;
        } 
        // Try sliding along Z axis only
        else if (!checkCollision(this.x, newZ)) {
          newX = this.x;
        }
        // Both blocked - add random jitter to escape
        else {
          newX = this.x + (Math.random() - 0.5) * 0.3;
          newZ = this.z + (Math.random() - 0.5) * 0.3;
        }
      }
      
      // Clamp to venue bounds
      this.x = Math.max(0.5, Math.min(this.venueWidth - 0.5, newX));
      this.z = Math.max(0.5, Math.min(this.venueDepth - 0.5, newZ));
      this.vx = vx;
      this.vz = vz;
    }
    
    return true;
  }

  toMessage(deviceId, venueId) {
    return {
      id: `person-${this.id}`,
      deviceId,
      venueId,
      timestamp: Date.now(),
      position: { x: this.x, y: 0, z: this.z },
      velocity: { x: this.vx || 0, y: 0, z: this.vz || 0 },
      objectType: 'person',
      color: this.color,
      boundingBox: { width: this.width, height: this.height, depth: this.width },
    };
  }
}

// Queue customer - simulates realistic queue behavior
class QueuePerson {
  constructor(id, queueZone, serviceZone, config = {}) {
    this.id = id;
    this.queueZone = queueZone;
    this.serviceZone = serviceZone;
    this.state = 'approaching'; // approaching -> queuing -> serving -> leaving -> done
    this.stateTime = 0;
    
    // Calculate flow direction: from queue zone toward service zone
    const dx = serviceZone.center.x - queueZone.center.x;
    const dz = serviceZone.center.z - queueZone.center.z;
    const flowLength = Math.sqrt(dx * dx + dz * dz) || 1;
    
    // Normalized flow direction (queue -> service)
    this.flowDirX = dx / flowLength;
    this.flowDirZ = dz / flowLength;
    
    // Perpendicular direction (for side-to-side variation)
    this.perpDirX = -this.flowDirZ;
    this.perpDirZ = this.flowDirX;
    
    // Queue length (distance from queue center to service center)
    this.queueLength = flowLength;
    
    // Start BEHIND the queue zone (opposite of flow direction)
    const approachOffset = 6 + Math.random() * 4;
    const sideOffset = (Math.random() - 0.5) * 3;
    this.x = queueZone.center.x - this.flowDirX * approachOffset + this.perpDirX * sideOffset;
    this.z = queueZone.center.z - this.flowDirZ * approachOffset + this.perpDirZ * sideOffset;
    this.targetX = this.x;
    this.targetZ = this.z;
    
    this.speed = 1.0 + Math.random() * 0.4;
    this.vx = 0;
    this.vz = 0;
    
    const checkoutRate = config.checkoutProbMultiplier || 1.0;
    this.targetWaitTime = (5 + Math.random() * 20) / checkoutRate;
    this.targetServiceTime = (3 + Math.random() * 8) / checkoutRate;
    
    this.color = '#f59e0b'; // Orange for queue customers
    this.width = 0.4 + Math.random() * 0.2;
    this.height = 1.5 + Math.random() * 0.4;
    this.done = false;
    
    this.setTargetForState();
  }

  setTargetForState() {
    const sideVariation = (Math.random() - 0.5) * 0.5;
    
    switch (this.state) {
      case 'approaching':
        // Target: back of queue zone
        this.targetX = this.queueZone.center.x + this.perpDirX * sideVariation;
        this.targetZ = this.queueZone.center.z + this.perpDirZ * sideVariation;
        break;
      case 'queuing':
        // Progress forward in queue toward service zone
        const queueProgress = this.stateTime / this.targetWaitTime;
        const progressDist = queueProgress * this.queueLength * 0.8;
        this.targetX = this.queueZone.center.x + this.flowDirX * progressDist + this.perpDirX * sideVariation * 0.3;
        this.targetZ = this.queueZone.center.z + this.flowDirZ * progressDist + this.perpDirZ * sideVariation * 0.3;
        break;
      case 'serving':
        // At the service zone (counter)
        this.targetX = this.serviceZone.center.x + this.perpDirX * sideVariation * 0.3;
        this.targetZ = this.serviceZone.center.z + this.perpDirZ * sideVariation * 0.3;
        break;
      case 'leaving':
        // Exit: continue past service zone in flow direction, then to the side
        const exitSide = Math.random() > 0.5 ? 1 : -1;
        this.targetX = this.serviceZone.center.x + this.flowDirX * 3 + this.perpDirX * exitSide * 4;
        this.targetZ = this.serviceZone.center.z + this.flowDirZ * 3 + this.perpDirZ * exitSide * 4;
        break;
    }
  }

  update(dt) {
    if (this.done) return false;
    
    this.stateTime += dt;
    const distToTarget = Math.sqrt(Math.pow(this.targetX - this.x, 2) + Math.pow(this.targetZ - this.z, 2));
    
    switch (this.state) {
      case 'approaching':
        if (distToTarget < 1.0) {
          this.state = 'queuing';
          this.stateTime = 0;
          this.setTargetForState();
        }
        break;
      case 'queuing':
        if (this.stateTime % 2 < dt) this.setTargetForState();
        if (this.stateTime >= this.targetWaitTime) {
          this.state = 'serving';
          this.stateTime = 0;
          this.setTargetForState();
        }
        break;
      case 'serving':
        if (this.stateTime >= this.targetServiceTime) {
          this.state = 'leaving';
          this.stateTime = 0;
          this.setTargetForState();
        }
        break;
      case 'leaving':
        if (distToTarget < 0.5 || this.stateTime > 5) {
          this.done = true;
          return false;
        }
        break;
    }
    
    // Movement with collision avoidance
    const dx = this.targetX - this.x;
    const dz = this.targetZ - this.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    
    if (dist > 0.1) {
      const effectiveSpeed = this.state === 'queuing' ? this.speed * 0.3 : this.speed;
      let vx = (dx / dist) * effectiveSpeed;
      let vz = (dz / dist) * effectiveSpeed;
      
      // Add soft avoidance force from obstacles
      const avoidance = getAvoidanceForce(this.x, this.z);
      vx += avoidance.x * effectiveSpeed;
      vz += avoidance.z * effectiveSpeed;
      
      // Calculate new position
      let newX = this.x + vx * dt;
      let newZ = this.z + vz * dt;
      
      // Simple collision check - if inside obstacle, try to slide around
      const obstacle = checkCollision(newX, newZ);
      if (obstacle) {
        // Try sliding along X axis only
        if (!checkCollision(newX, this.z)) {
          newZ = this.z;
        } 
        // Try sliding along Z axis only
        else if (!checkCollision(this.x, newZ)) {
          newX = this.x;
        }
        // Both blocked - add random jitter to escape
        else {
          newX = this.x + (Math.random() - 0.5) * 0.2;
          newZ = this.z + (Math.random() - 0.5) * 0.2;
        }
      }
      
      this.x = newX;
      this.z = newZ;
      this.vx = vx;
      this.vz = vz;
    } else {
      this.vx = 0;
      this.vz = 0;
    }
    
    return true;
  }

  toMessage(deviceId, venueId) {
    return {
      id: `queue-${this.id}`,
      deviceId,
      venueId,
      timestamp: Date.now(),
      position: { x: this.x, y: 0, z: this.z },
      velocity: { x: this.vx, y: 0, z: this.vz },
      objectType: 'person',
      color: this.color,
      boundingBox: { width: this.width, height: this.height, depth: this.width },
      metadata: { state: this.state }
    };
  }
}

let queuePeople = [];
let lastQueueSpawnTime = 0;
let nextQueueId = 1000;

// Initialize people with staggered spawning (max 5-6 per cluster)
const initializePeople = () => {
  people = [];
  const maxPerCluster = 5;
  const clusterInterval = 30; // 30 seconds between clusters
  const withinClusterDelay = 3; // 3 seconds between people in same cluster
  
  for (let i = 0; i < config.personCount; i++) {
    const clusterIndex = Math.floor(i / maxPerCluster);
    const positionInCluster = i % maxPerCluster;
    // Stagger spawn: cluster delay + within-cluster delay + small random offset
    const spawnDelay = (clusterIndex * clusterInterval) + (positionInCluster * withinClusterDelay) + (Math.random() * 2);
    people.push(new Person(i, config.venueWidth, config.venueDepth, spawnDelay));
  }
  console.log(`Initialized ${config.personCount} people with staggered spawning (${Math.ceil(config.personCount / maxPerCluster)} clusters)`);
};

// Connect to MQTT
const connectMqtt = () => {
  return new Promise((resolve, reject) => {
    if (mqttClient) {
      mqttClient.end(true);
    }

    console.log(`Connecting to MQTT broker: ${config.mqttBroker}`);
    mqttClient = mqtt.connect(config.mqttBroker, {
      reconnectPeriod: 5000,
      connectTimeout: 10000,
    });

    mqttClient.on('connect', () => {
      console.log('Connected to MQTT broker');
      stats.mqttConnected = true;
      stats.lastError = null;
      resolve();
    });

    mqttClient.on('error', (err) => {
      console.error('MQTT Error:', err.message);
      stats.lastError = err.message;
      stats.mqttConnected = false;
      reject(err);
    });

    mqttClient.on('close', () => {
      stats.mqttConnected = false;
    });

    mqttClient.on('reconnect', () => {
      console.log('Reconnecting to MQTT broker...');
    });
  });
};

// Spawn a new queue customer
const spawnQueuePerson = () => {
  if (cashierZones.length === 0) return;
  const zone = cashierZones[Math.floor(Math.random() * cashierZones.length)];
  const person = new QueuePerson(nextQueueId++, zone.queueZone, zone.serviceZone, config);
  queuePeople.push(person);
  console.log(`Spawned queue customer ${person.id} at ${zone.name}`);
};

// Start simulation
const startSimulation = async () => {
  if (isRunning) return { success: false, error: 'Already running' };

  try {
    await connectMqtt();
    
    // Reset state
    people = [];
    queuePeople = [];
    lastQueueSpawnTime = Date.now();
    stats.tracksSent = 0;
    stats.startTime = Date.now();
    stats.lastError = null;

    // Always fetch geometry for collision avoidance
    console.log('Fetching venue geometry...');
    venueGeometry = await fetchVenueGeometry();
    if (venueGeometry) {
      // Parse obstacles for collision avoidance (all modes)
      obstacles = parseObstacles(venueGeometry);
      
      // Update venue dimensions from geometry
      if (venueGeometry.venue) {
        config.venueWidth = venueGeometry.venue.width || config.venueWidth;
        config.venueDepth = venueGeometry.venue.depth || config.venueDepth;
      }
      
      // Parse cashier zones for queue modes
      if (config.simulationMode === 'queue' || config.simulationMode === 'mixed') {
        cashierZones = parseCashierZones(venueGeometry);
        if (cashierZones.length === 0) {
          console.warn('No cashier zones found! Run Smart KPI to generate zones.');
          if (config.simulationMode === 'queue') {
            return { success: false, error: 'No cashier zones found. Generate zones with Smart KPI first.' };
          }
        }
      }
      
      // Parse cashier gaps (one-way exit zones) for all modes
      cashierGapZones = parseCashierGaps(venueGeometry);
      
      // Parse entrance objects for spawning
      entranceObjects = parseEntrances(venueGeometry);
      if (entranceObjects.length === 0) {
        console.warn('No entrance objects found! People will spawn at venue edge.');
      }
      
      // Initialize SimulatorV2 if enabled
      if (config.useSimV2) {
        console.log('[SimV2] Initializing V2 simulation...');
        // Build SimV2 config from frontend config
        const simV2Config = {
          maxOccupancy: config.targetPeopleCount,
          seed: null, // Random seed
          // Cashier feature flags
          ENABLE_CASHIER_AGENTS: config.enableCashiers,
          ENABLE_ID_CONFUSION: config.enableIdConfusion,
          // Checkout Manager settings
          enableCheckoutManager: config.enableCheckoutManager,
          queuePressureThreshold: config.queuePressureThreshold || 5,
          // Pass checkout zones with queueZoneId (UUID) for unified lane identification
          checkoutZones: cashierZones,
        };
        
        // Override cashier behavior settings if provided
        if (config.enableCashiers) {
          simV2Config.cashierBehavior = {
            cashiersPerLane: 1,
            spawnAtStart: true,
            shiftDurationMin: [config.cashierShiftMin * 0.5, config.cashierShiftMin * 1.5],
            breakProbabilityPerHour: config.cashierBreakProb / 100,
          };
          simV2Config.laneOpenClose = {
            openConfirmWindowSec: config.laneOpenConfirmSec,
            closeGraceWindowSec: 180,
          };
        }
        
        simulatorV2 = new SimulatorV2(config.venueWidth, config.venueDepth, simV2Config);
        simulatorV2.initFromScene(venueGeometry.objects || [], venueGeometry.rois || []);
        
        // Log cashier status
        const cashierCount = simulatorV2.cashierAgents?.length || 0;
        const laneCount = simulatorV2.laneStates?.length || 0;
        console.log(`[SimV2] Cashiers: ${cashierCount} agents spawned for ${laneCount} lanes`);
        console.log(`[SimV2] Cashier config: enabled=${config.enableCashiers}, shift=${config.cashierShiftMin}min, break=${config.cashierBreakProb}%`);
        
        if (cashierCount > 0) {
          for (const c of simulatorV2.cashierAgents) {
            console.log(`[SimV2] Cashier ${c.id}: lane=${c.laneId}, anchor=(${c.anchorPoint.x.toFixed(1)}, ${c.anchorPoint.z.toFixed(1)}), state=${c.state}`);
          }
        }
        
        // Bulk spawn initial agents to reach target quickly
        const initialSpawn = Math.min(config.targetPeopleCount, 50);
        console.log(`[SimV2] Bulk spawning ${initialSpawn} initial agents (target: ${config.targetPeopleCount})`);
        for (let i = 0; i < initialSpawn; i++) {
          simulatorV2.spawnAgent();
        }
        console.log(`[SimV2] Initialization complete, active: ${simulatorV2.getActiveCount()}`);
      }
    } else {
      obstacles = []; // Reset obstacles if no geometry
      cashierGapZones = [];
      entranceObjects = [];
      simulatorV2 = null;
      console.warn('Could not fetch venue geometry - collision avoidance disabled');
    }

    // Initialize random walkers if mode is random or mixed (V1 only)
    if (!config.useSimV2 && (config.simulationMode === 'random' || config.simulationMode === 'mixed')) {
      initializePeople();
    }

    // Spawn initial queue customers (V1 only)
    if (!config.useSimV2 && (config.simulationMode === 'queue' || config.simulationMode === 'mixed') && cashierZones.length > 0) {
      for (let i = 0; i < Math.min(3, cashierZones.length); i++) {
        spawnQueuePerson();
      }
    }

    const intervalMs = 1000 / config.frequencyHz;
    const dt = 1 / config.frequencyHz;
    
    // IMMEDIATE DEBUG LOG
    console.log('====== SIMULATION STARTING ======');
    console.log(`ENABLE_CASHIER_AGENTS: ${config.enableCashiers}`);
    if (simulatorV2) {
      console.log(`NavGrid cashiers detected: ${simulatorV2.navGrid?.cashiers?.length || 0}`);
      console.log(`CashierAgents array: ${simulatorV2.cashierAgents?.length || 0}`);
      console.log(`LaneStates array: ${simulatorV2.laneStates?.length || 0}`);
    }
    console.log('=================================');

    simulationInterval = setInterval(() => {
      if (!mqttClient || !stats.mqttConnected) return;

      const now = Date.now();

      // ========== V2 SIMULATION ==========
      if (config.useSimV2 && simulatorV2) {
        // Spawn new agents if below target (apply arrival rate multiplier)
        const activeCount = simulatorV2.getActiveCount();
        const arrivalMultiplier = config.arrivalRateMultiplier || 1.0;
        const effectiveTarget = Math.floor(config.targetPeopleCount * arrivalMultiplier);
        if (activeCount < effectiveTarget) {
          const spawnChance = Math.min(0.5, (effectiveTarget - activeCount) / effectiveTarget) * arrivalMultiplier;
          if (Math.random() < spawnChance * dt * 2) {
            simulatorV2.spawnAgent();
          }
        }
        
        // Update simulation
        simulatorV2.update(dt);
        
        // Publish active customer agents
        const agents = simulatorV2.getActiveAgents();
        for (const agent of agents) {
          const message = agent.toMessage(config.deviceId, config.venueId);
          mqttClient.publish(
            `hyperspace/trajectories/${config.deviceId}`,
            JSON.stringify(message)
          );
          stats.tracksSent++;
        }
        
        // Publish active cashier agents
        const cashiers = simulatorV2.getActiveCashiers();
        for (const cashier of cashiers) {
          const message = cashier.toMessage(config.deviceId, config.venueId);
          mqttClient.publish(
            `hyperspace/trajectories/${config.deviceId}`,
            JSON.stringify(message)
          );
          stats.tracksSent++;
        }
        
        // Debug log all cashiers every 5 seconds
        if (!global.lastCashierLog || Date.now() - global.lastCashierLog > 5000) {
          global.lastCashierLog = Date.now();
          const allCashiers = simulatorV2.cashierAgents || [];
          console.log(`[Cashier Debug] Total: ${allCashiers.length}, Active: ${cashiers.length}`);
          for (const c of allCashiers) {
            console.log(`  Cashier ${c.id}: state=${c.state}, spawned=${c.spawned}, pos=(${c.x.toFixed(1)}, ${c.z.toFixed(1)}), lane=${c.laneId}`);
          }
        }
        
        // Prune exited agents periodically
        if (Math.random() < 0.01) {
          simulatorV2.pruneExitedAgents();
        }
        
        return;
      }

      // ========== V1 SIMULATION (fallback) ==========
      // Spawn new queue customers periodically
      if ((config.simulationMode === 'queue' || config.simulationMode === 'mixed') && 
          cashierZones.length > 0 &&
          now - lastQueueSpawnTime > config.queueSpawnInterval * 1000) {
        spawnQueuePerson();
        lastQueueSpawnTime = now;
      }

      // Count active people in scene
      const activePeople = people.filter(p => p.spawned && !p.done).length;
      
      // Spawn new people if below target (with rate limiting)
      if (activePeople < config.targetPeopleCount && people.length < config.targetPeopleCount * 2) {
        // Spawn rate: roughly 1 person per 2-5 seconds when below target
        const spawnChance = Math.min(0.5, (config.targetPeopleCount - activePeople) / config.targetPeopleCount);
        if (Math.random() < spawnChance * dt) {
          const newId = people.length > 0 ? Math.max(...people.map(p => p.id)) + 1 : 0;
          const newPerson = new Person(newId, config.venueWidth, config.venueDepth, 0);
          people.push(newPerson);
        }
      }

      // Update and publish random walkers
      for (let i = people.length - 1; i >= 0; i--) {
        const person = people[i];
        const alive = person.update(dt);
        
        if (alive && person.spawned) {
          // Only publish if person has actually spawned (not waiting in delay)
          const message = person.toMessage(config.deviceId, config.venueId);
          mqttClient.publish(
            `hyperspace/trajectories/${config.deviceId}`,
            JSON.stringify(message)
          );
          stats.tracksSent++;
        } else if (!alive) {
          // Person exited - remove from array (will be replaced by dynamic spawning)
          console.log(`Person ${person.id} exited after ${Math.floor(person.totalTime)}s`);
          people.splice(i, 1);
        }
      }

      // Update and publish queue customers
      queuePeople = queuePeople.filter((person) => {
        const alive = person.update(dt);
        if (alive) {
          const message = person.toMessage(config.deviceId, config.venueId);
          mqttClient.publish(
            `hyperspace/trajectories/${config.deviceId}`,
            JSON.stringify(message)
          );
          stats.tracksSent++;
        }
        return alive;
      });
    }, intervalMs);

    isRunning = true;
    const simType = config.useSimV2 ? 'V2 (navgrid+pathfinding)' : 'V1 (legacy)';
    console.log(`Simulation started: ${simType}, mode=${config.simulationMode}, target=${config.targetPeopleCount} at ${config.frequencyHz}Hz`);
    return { success: true, cashierZones: cashierZones.length, simVersion: config.useSimV2 ? 'V2' : 'V1' };
  } catch (err) {
    stats.lastError = err.message;
    return { success: false, error: err.message };
  }
};

// Stop simulation
const stopSimulation = () => {
  if (simulationInterval) {
    clearInterval(simulationInterval);
    simulationInterval = null;
  }
  if (mqttClient) {
    mqttClient.end(true);
    mqttClient = null;
  }
  if (simulatorV2) {
    simulatorV2.reset();
  }
  isRunning = false;
  stats.mqttConnected = false;
  console.log('Simulation stopped');
  return { success: true };
};

// API Routes
app.get('/api/config', (req, res) => {
  res.json(config);
});

app.post('/api/config', async (req, res) => {
  const wasRunning = isRunning;
  console.log(`[API] POST /api/config from ${req.ip} - wasRunning=${wasRunning}, changes:`, Object.keys(req.body));
  if (wasRunning) {
    console.log('[API] Stopping simulation due to config change');
    stopSimulation();
  }

  config = { ...config, ...req.body };
  saveConfig();

  // Auto-restart if was running
  if (wasRunning) {
    console.log('[API] Auto-restarting simulation with new config');
    await new Promise(r => setTimeout(r, 500)); // Brief delay for cleanup
    await startSimulation();
  }

  res.json({ success: true, config, restarted: wasRunning });
});

app.get('/api/status', (req, res) => {
  let activePeopleCount;
  let simDiagnostics = null;
  
  if (config.useSimV2 && simulatorV2) {
    activePeopleCount = simulatorV2.getActiveCount();
    simDiagnostics = simulatorV2.getDiagnostics();
  } else {
    activePeopleCount = people.filter(p => p.spawned && !p.done).length + queuePeople.length;
  }
  
  res.json({
    isRunning,
    mqttConnected: stats.mqttConnected,
    tracksSent: stats.tracksSent,
    uptime: stats.startTime ? Math.floor((Date.now() - stats.startTime) / 1000) : 0,
    lastError: stats.lastError,
    activePeopleCount,
    simVersion: config.useSimV2 ? 'V2' : 'V1',
    simDiagnostics,
    config,
  });
});

app.get('/api/diagnostics', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.json({ error: 'SimV2 not enabled', simVersion: 'V1' });
  }
  
  res.json({
    diagnostics: simulatorV2.getDiagnostics(),
    heatmap: simulatorV2.getHeatmap(),
  });
});

// Debug endpoint: full journey analysis with wireframe
app.get('/api/debug/journey', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.json({ error: 'SimV2 not enabled' });
  }
  
  const debug = simulatorV2.debugFullJourney();
  
  // If text format requested, return plain text
  if (req.query.format === 'text') {
    res.type('text/plain');
    return res.send(debug.textWireframe + '\n\n' + debug.asciiGrid);
  }
  
  res.json(debug);
});

// Debug endpoint: list all agents with positions for overlap detection
app.get('/api/debug/agents', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.json({ error: 'SimV2 not enabled', simVersion: 'V1' });
  }
  
  const agents = simulatorV2.getActiveAgents();
  const agentData = agents.map(a => ({
    id: a.id,
    x: Math.round(a.x * 100) / 100,
    z: Math.round(a.z * 100) / 100,
    state: a.state,
    persona: a.persona,
    speed: Math.round(a.speed * 100) / 100,
    blocked: a.blockedFrames,
    nearbyAgents: a.nearbyAgentCount,
    queueState: a.queueSubState,
    isInQueue: a.isInQueueSystem,
  }));
  
  // Find overlapping agents (within 0.5m of each other)
  const overlaps = [];
  for (let i = 0; i < agentData.length; i++) {
    for (let j = i + 1; j < agentData.length; j++) {
      const a1 = agentData[i];
      const a2 = agentData[j];
      const dist = Math.sqrt(Math.pow(a1.x - a2.x, 2) + Math.pow(a1.z - a2.z, 2));
      if (dist < 0.5) {
        overlaps.push({
          agent1: a1.id,
          agent2: a2.id,
          distance: Math.round(dist * 100) / 100,
          pos1: { x: a1.x, z: a1.z },
          pos2: { x: a2.x, z: a2.z },
          states: [a1.state, a2.state],
        });
      }
    }
  }
  
  // Group agents by state
  const byState = {};
  for (const a of agentData) {
    byState[a.state] = (byState[a.state] || 0) + 1;
  }
  
  // Find stuck agents (high blocked frames)
  const stuckAgents = agentData.filter(a => a.blocked > 30);
  
  res.json({
    totalActive: agents.length,
    byState,
    overlaps,
    overlapCount: overlaps.length,
    stuckAgents,
    stuckCount: stuckAgents.length,
    agents: agentData,
  });
});

// ========== CHECKOUT MANAGER API ENDPOINTS ==========

// Get checkout lanes status
app.get('/api/checkout/status', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.status(400).json({ error: 'SimV2 not enabled' });
  }
  
  if (!config.enableCheckoutManager) {
    return res.status(400).json({ error: 'Checkout Manager not enabled' });
  }
  
  const laneStateController = simulatorV2.laneStateController;
  if (!laneStateController) {
    return res.status(400).json({ error: 'LaneStateController not initialized' });
  }
  
  res.json({
    lanes: laneStateController.getAllLaneStatus(),
    pressure: laneStateController.getQueuePressure(),
    thresholds: {
      queuePressureThreshold: laneStateController.config.queuePressureThreshold,
      inflowRateThreshold: laneStateController.config.inflowRateThreshold,
    }
  });
});

// Set lane state (open/close)
app.post('/api/checkout/set_lane_state', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.status(400).json({ error: 'SimV2 not enabled' });
  }
  
  if (!config.enableCheckoutManager) {
    return res.status(400).json({ error: 'Checkout Manager not enabled' });
  }
  
  const laneStateController = simulatorV2.laneStateController;
  if (!laneStateController) {
    return res.status(400).json({ error: 'LaneStateController not initialized' });
  }
  
  const { laneId, state } = req.body;
  if (laneId === undefined || !state) {
    return res.status(400).json({ error: 'laneId and state are required' });
  }
  
  console.log(`[Checkout Manager] Setting lane ${laneId} to ${state}`);
  const result = laneStateController.setLaneState(laneId, state);
  res.json(result);
});

// Update thresholds
app.post('/api/checkout/thresholds', (req, res) => {
  if (!config.useSimV2 || !simulatorV2) {
    return res.status(400).json({ error: 'SimV2 not enabled' });
  }
  
  if (!config.enableCheckoutManager) {
    return res.status(400).json({ error: 'Checkout Manager not enabled' });
  }
  
  const laneStateController = simulatorV2.laneStateController;
  if (!laneStateController) {
    return res.status(400).json({ error: 'LaneStateController not initialized' });
  }
  
  const { queuePressureThreshold, inflowRateThreshold } = req.body;
  laneStateController.updateThresholds({ queuePressureThreshold, inflowRateThreshold });
  
  // Also save to config
  if (queuePressureThreshold !== undefined) {
    config.queuePressureThreshold = queuePressureThreshold;
  }
  if (inflowRateThreshold !== undefined) {
    config.inflowRateThreshold = inflowRateThreshold;
  }
  saveConfig();
  
  res.json({ 
    success: true, 
    thresholds: {
      queuePressureThreshold: laneStateController.config.queuePressureThreshold,
      inflowRateThreshold: laneStateController.config.inflowRateThreshold,
    }
  });
});

// ========== END CHECKOUT MANAGER API ==========

// ========== EDGE COMMISSIONING API ==========
// These endpoints are called by the main server's Edge Commissioning Portal

// In-memory LiDAR inventory (would be populated by real LAN scans in production)
let lidarInventory = [];
let appliedConfigHash = null;
let appliedConfig = null;

// Known LiDAR ports and vendors
const LIDAR_SIGNATURES = [
  { vendor: 'RoboSense', ports: [6699, 7788, 80], httpCheck: true }, // RoboSense (MSOP/DIFOP/Web)
  { vendor: 'Livox', ports: [56000, 56001], httpCheck: false },
  { vendor: 'Ouster', ports: [7502, 7503], httpCheck: false },
  { vendor: 'Velodyne', ports: [2368, 8308], httpCheck: false },
  { vendor: 'Hesai', ports: [2368, 9870], httpCheck: false },
];

// Scan a single IP for LiDAR devices
async function probeLidarIp(ip, timeout = 2000) {
  const results = [];
  
  for (const sig of LIDAR_SIGNATURES) {
    for (const port of sig.ports) {
      try {
        // Try TCP connect
        const isOpen = await new Promise((resolve) => {
          const socket = new net.Socket();
          socket.setTimeout(timeout);
          
          socket.on('connect', () => {
            socket.destroy();
            resolve(true);
          });
          socket.on('timeout', () => {
            socket.destroy();
            resolve(false);
          });
          socket.on('error', () => {
            socket.destroy();
            resolve(false);
          });
          
          socket.connect(port, ip);
        });
        
        if (isOpen) {
          // Try HTTP check for web interface (RoboSense has web UI)
          let model = 'Unknown';
          if (sig.httpCheck && port === 80) {
            try {
              const controller = new AbortController();
              const timeoutId = setTimeout(() => controller.abort(), timeout);
              const httpRes = await fetch(`http://${ip}/`, { signal: controller.signal });
              clearTimeout(timeoutId);
              const html = await httpRes.text();
              if (html.includes('robosense') || html.includes('RoboSense')) {
                model = 'RoboSense LiDAR';
              }
            } catch (e) { /* ignore */ }
          }
          
          results.push({
            lidarId: `lidar-${ip.replace(/\./g, '-')}`,
            ip,
            vendor: sig.vendor,
            model,
            port,
            reachable: true,
          });
          break; // Found a match for this vendor, no need to check other ports
        }
      } catch (err) {
        // Ignore connection errors
      }
    }
  }
  
  return results;
}

// POST /api/edge/lidar/scan - Trigger LAN scan for LiDAR devices
app.post('/api/edge/lidar/scan', async (req, res) => {
  console.log('[Edge Commissioning] LiDAR LAN scan triggered');
  
  const { subnet, targetIps, quickScan } = req.body;
  const baseSubnet = subnet || '192.168.1';
  
  const startTime = Date.now();
  const foundLidars = [];
  
  // Step 1: Prioritize commissioned LiDARs first (fastest response)
  const commissionedIps = commissionedLidars.map(l => l.assignedIp).filter(Boolean);
  if (commissionedIps.length > 0) {
    console.log(`[Edge Commissioning] Priority scan: ${commissionedIps.length} commissioned LiDARs first...`);
    const priorityResults = await Promise.all(commissionedIps.map(ip => probeLidarIp(ip, 1500)));
    for (const r of priorityResults) foundLidars.push(...r);
  }
  
  // Step 2: Scan remaining IPs
  const alreadyScanned = new Set(commissionedIps);
  
  // If specific IPs provided, only scan those
  if (targetIps && Array.isArray(targetIps) && targetIps.length > 0) {
    const remaining = targetIps.filter(ip => !alreadyScanned.has(ip));
    console.log(`[Edge Commissioning] Scanning ${remaining.length} specific IPs...`);
    const results = await Promise.all(remaining.map(ip => probeLidarIp(ip, 2000)));
    for (const r of results) foundLidars.push(...r);
  } 
  // Quick scan: 200-250 range (covers most LiDAR deployments)
  else if (quickScan !== false) {
    const scanIps = [];
    for (let i = 200; i <= 250; i++) {
      const ip = `${baseSubnet}.${i}`;
      if (!alreadyScanned.has(ip)) scanIps.push(ip);
    }
    console.log(`[Edge Commissioning] Quick scan: ${baseSubnet}.200-250 (${scanIps.length} IPs)...`);
    const results = await Promise.all(scanIps.map(ip => probeLidarIp(ip, 1000)));
    for (const r of results) foundLidars.push(...r);
  }
  // Full scan (slow)
  else {
    console.log(`[Edge Commissioning] Full scan: ${baseSubnet}.0/24 (this may take a while)...`);
    const ipsToScan = [];
    for (let i = 1; i <= 254; i++) {
      const ip = `${baseSubnet}.${i}`;
      if (!alreadyScanned.has(ip)) ipsToScan.push(ip);
    }
    
    const batchSize = 50;
    for (let i = 0; i < ipsToScan.length; i += batchSize) {
      const batch = ipsToScan.slice(i, i + batchSize);
      const batchResults = await Promise.all(batch.map(ip => probeLidarIp(ip, 500)));
      for (const r of batchResults) foundLidars.push(...r);
    }
  }
  
  const scanDuration = Date.now() - startTime;
  console.log(`[Edge Commissioning] Scan complete: found ${foundLidars.length} LiDARs in ${scanDuration}ms`);
  
  lidarInventory = foundLidars;
  
  res.json({
    ok: true,
    foundCount: lidarInventory.length,
    lidars: lidarInventory,
    scanTime: new Date().toISOString(),
    scanDurationMs: scanDuration,
  });
});

// GET /api/edge/lidar/inventory - Get discovered LiDAR devices with live reachability check
app.get('/api/edge/lidar/inventory', async (req, res) => {
  console.log('[Edge Commissioning] Inventory requested - checking reachability...');
  
  try {
    // Quick TCP ping to check if each LiDAR is actually reachable
    const checkReachable = (ip, port = 80, timeout = 1500) => {
      return new Promise((resolve) => {
        try {
          const socket = new net.Socket();
          socket.setTimeout(timeout);
          socket.on('connect', () => { socket.destroy(); resolve(true); });
          socket.on('error', () => { socket.destroy(); resolve(false); });
          socket.on('timeout', () => { socket.destroy(); resolve(false); });
          socket.connect(port, ip);
        } catch (err) {
          console.error(`[Edge Commissioning] Ping error for ${ip}:`, err.message);
          resolve(false);
        }
      });
    };
    
    // Check all LiDARs in parallel
    const lidarsWithStatus = await Promise.all(
      lidarInventory.map(async (lidar) => {
        try {
          const reachable = await checkReachable(lidar.ip, lidar.ports?.[0] || 80);
          return { ...lidar, reachable };
        } catch (err) {
          console.error(`[Edge Commissioning] Error checking ${lidar.ip}:`, err.message);
          return { ...lidar, reachable: false };
        }
      })
    );
    
    const onlineCount = lidarsWithStatus.filter(l => l.reachable).length;
    console.log(`[Edge Commissioning] Inventory: ${onlineCount}/${lidarsWithStatus.length} LiDARs online`);
    
    res.json({
      lidars: lidarsWithStatus,
      lastScanTime: lidarInventory.length > 0 ? new Date().toISOString() : null,
    });
  } catch (err) {
    console.error('[Edge Commissioning] Inventory error:', err.message);
    // Fallback: return inventory without live check
    res.json({
      lidars: lidarInventory,
      lastScanTime: lidarInventory.length > 0 ? new Date().toISOString() : null,
      error: err.message,
    });
  }
});

// ========== ROBOSENSE COMMISSIONING API ==========

// Commissioned LiDARs storage
let commissionedLidars = [];
const COMMISSIONED_FILE = join(__dirname, 'data', 'commissioned-lidars.json');

// Load commissioned LiDARs from file
function loadCommissionedLidars() {
  try {
    if (fs.existsSync(COMMISSIONED_FILE)) {
      commissionedLidars = JSON.parse(fs.readFileSync(COMMISSIONED_FILE, 'utf-8'));
      console.log(`[Commissioner] Loaded ${commissionedLidars.length} commissioned LiDARs`);
    }
  } catch (err) {
    console.error('[Commissioner] Error loading commissioned LiDARs:', err.message);
  }
}

// Save commissioned LiDARs to file
function saveCommissionedLidars() {
  try {
    const dir = dirname(COMMISSIONED_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(COMMISSIONED_FILE, JSON.stringify(commissionedLidars, null, 2));
  } catch (err) {
    console.error('[Commissioner] Error saving commissioned LiDARs:', err.message);
  }
}

// Initialize
loadCommissionedLidars();

// POST /api/edge/lidar/discover-robosense - Listen for RoboSense DIFOP broadcasts
app.post('/api/edge/lidar/discover-robosense', async (req, res) => {
  const { timeout = 5000 } = req.body;
  console.log(`[Commissioner] Starting RoboSense discovery (${timeout}ms)...`);
  
  try {
    const devices = await listenForDifop(timeout);
    res.json({
      ok: true,
      foundCount: devices.length,
      devices,
    });
  } catch (err) {
    console.error('[Commissioner] Discovery error:', err.message);
    res.status(500).json({ ok: false, error: err.message });
  }
});

// POST /api/edge/lidar/probe - Probe specific IP for RoboSense
app.post('/api/edge/lidar/probe', async (req, res) => {
  const { ip = '192.168.1.200' } = req.body;
  console.log(`[Commissioner] Probing ${ip}...`);
  
  try {
    const result = await probeRoboSense(ip, 3000);
    res.json(result);
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// GET /api/edge/lidar/commissioned - Get list of commissioned LiDARs
app.get('/api/edge/lidar/commissioned', (req, res) => {
  res.json({
    lidars: commissionedLidars,
    nextAvailableIp: getNextAvailableIp(),
  });
});

// Helper: Get next available IP for commissioning
function getNextAvailableIp(baseSubnet = '192.168.1', startFrom = 201) {
  const usedIps = new Set(commissionedLidars.map(l => l.assignedIp));
  for (let i = startFrom; i <= 254; i++) {
    const ip = `${baseSubnet}.${i}`;
    if (!usedIps.has(ip)) return ip;
  }
  return null;
}

// POST /api/edge/lidar/commission - Commission a LiDAR (assign new IP)
app.post('/api/edge/lidar/commission', async (req, res) => {
  const { 
    currentIp = '192.168.1.200', 
    newIp,
    label,
    destIp = '192.168.1.102' // Edge server's IP for receiving data
  } = req.body;
  
  const assignedIp = newIp || getNextAvailableIp();
  
  if (!assignedIp) {
    return res.status(400).json({ ok: false, error: 'No available IPs' });
  }
  
  console.log(`[Commissioner] Commissioning LiDAR at ${currentIp} -> ${assignedIp}`);
  
  // For now, we can't auto-change IP without knowing exact protocol
  // Instead, provide instructions and register the intent
  
  const commissionRecord = {
    id: `lidar-${Date.now()}`,
    originalIp: currentIp,
    assignedIp,
    destIp,
    label: label || `LiDAR-${assignedIp.split('.').pop()}`,
    commissionedAt: new Date().toISOString(),
    status: 'pending', // pending = needs manual IP change, active = confirmed
  };
  
  commissionedLidars.push(commissionRecord);
  saveCommissionedLidars();
  
  res.json({
    ok: true,
    message: 'Commission record created. Change LiDAR IP via web interface.',
    record: commissionRecord,
    instructions: [
      `1. Open browser to http://${currentIp}`,
      `2. Go to Network Settings`,
      `3. Change LiDAR IP to: ${assignedIp}`,
      `4. Set Destination IP to: ${destIp}`,
      `5. Save and reboot LiDAR`,
      `6. Label physical device: "${commissionRecord.label}"`,
      `7. Call /api/edge/lidar/confirm-commission to verify`,
    ],
  });
});

// POST /api/edge/lidar/confirm-commission - Confirm a commissioned LiDAR is reachable
app.post('/api/edge/lidar/confirm-commission', async (req, res) => {
  const { lidarId, ip } = req.body;
  
  // Find the commission record
  const record = commissionedLidars.find(l => 
    l.id === lidarId || l.assignedIp === ip
  );
  
  if (!record) {
    return res.status(404).json({ ok: false, error: 'Commission record not found' });
  }
  
  // Try to reach the LiDAR at assigned IP
  const testIp = ip || record.assignedIp;
  console.log(`[Commissioner] Confirming LiDAR at ${testIp}...`);
  
  try {
    const isReachable = await new Promise((resolve) => {
      const socket = new net.Socket();
      socket.setTimeout(2000);
      socket.on('connect', () => { socket.destroy(); resolve(true); });
      socket.on('timeout', () => { socket.destroy(); resolve(false); });
      socket.on('error', () => { socket.destroy(); resolve(false); });
      socket.connect(80, testIp);
    });
    
    if (isReachable) {
      record.status = 'active';
      record.confirmedAt = new Date().toISOString();
      saveCommissionedLidars();
      
      res.json({
        ok: true,
        message: 'LiDAR confirmed active',
        record,
      });
    } else {
      res.json({
        ok: false,
        message: `LiDAR not reachable at ${testIp}`,
        record,
      });
    }
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// DELETE /api/edge/lidar/commissioned/:id - Remove a commissioned LiDAR
app.delete('/api/edge/lidar/commissioned/:id', (req, res) => {
  const { id } = req.params;
  const idx = commissionedLidars.findIndex(l => l.id === id);
  
  if (idx === -1) {
    return res.status(404).json({ ok: false, error: 'Not found' });
  }
  
  const removed = commissionedLidars.splice(idx, 1)[0];
  saveCommissionedLidars();
  
  res.json({ ok: true, removed });
});

// POST /api/edge/lidar/set-ip - Try to change LiDAR IP via HTTP
app.post('/api/edge/lidar/set-ip', async (req, res) => {
  const { currentIp = '192.168.1.200', newIp, destIp = '192.168.1.102' } = req.body;
  
  if (!newIp) {
    return res.status(400).json({ ok: false, error: 'newIp is required' });
  }
  
  console.log(`[Commissioner] Attempting to change IP: ${currentIp} -> ${newIp}`);
  
  try {
    const result = await setLidarIpViaHttp(currentIp, newIp, destIp);
    res.json(result);
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// GET /api/edge/lidar/get-config/:ip - Get LiDAR config via HTTP
app.get('/api/edge/lidar/get-config/:ip', async (req, res) => {
  const { ip } = req.params;
  
  console.log(`[Commissioner] Getting config from ${ip}...`);
  
  try {
    const result = await getLidarConfigViaHttp(ip);
    res.json(result);
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ========== END ROBOSENSE COMMISSIONING API ==========

// ========== POINT CLOUD STREAMING API ==========

// GET /api/edge/pcl/snapshot - Capture a single frame point cloud from a LiDAR
app.get('/api/edge/pcl/snapshot', async (req, res) => {
  const { 
    ip = '192.168.1.200', 
    duration = 100,
    maxPoints = 30000,
    downsample = 2,
    format = 'json', // json, binary, ply
    model = 'RS16'
  } = req.query;
  
  console.log(`[PointCloud] Snapshot requested from ${ip} (format=${format}, duration=${duration}ms)`);
  
  try {
    const result = await capturePointCloudSnapshot(ip, {
      duration: parseInt(duration),
      maxPoints: parseInt(maxPoints),
      downsample: parseInt(downsample),
      model,
    });
    
    if (!result.success || result.pointCount === 0) {
      return res.status(404).json({
        success: false,
        error: 'No point cloud data received',
        lidarIp: ip,
        packetsReceived: result.packetsReceived || 0,
      });
    }
    
    // Return based on requested format
    if (format === 'binary') {
      const buffer = pointsToBuffer(result.points);
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('X-Point-Count', result.pointCount);
      res.setHeader('X-Lidar-IP', ip);
      return res.send(buffer);
    }
    
    if (format === 'ply') {
      const ply = pointsToPly(result.points);
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="pointcloud-${ip.replace(/\./g, '-')}.ply"`);
      return res.send(ply);
    }
    
    // Default: JSON (but with compact points array for efficiency)
    res.json({
      success: true,
      lidarIp: ip,
      pointCount: result.pointCount,
      packetsReceived: result.packetsReceived,
      timestamp: Date.now(),
      // Compact format: flat array [x,y,z,i, x,y,z,i, ...]
      points: result.points.flatMap(p => [
        Math.round(p.x * 1000) / 1000,
        Math.round(p.y * 1000) / 1000,
        Math.round(p.z * 1000) / 1000,
        p.intensity
      ]),
    });
  } catch (err) {
    console.error('[PointCloud] Snapshot error:', err.message);
    res.status(500).json({
      success: false,
      error: err.message,
      lidarIp: ip,
    });
  }
});

// POST /api/edge/pcl/snapshot - Same as GET but with body params
app.post('/api/edge/pcl/snapshot', async (req, res) => {
  const { 
    ip = '192.168.1.200', 
    duration = 100,
    maxPoints = 30000,
    downsample = 2,
    format = 'json',
    model = 'RS16'
  } = req.body;
  
  console.log(`[PointCloud] Snapshot requested from ${ip} (format=${format}, duration=${duration}ms)`);
  
  try {
    const result = await capturePointCloudSnapshot(ip, {
      duration: parseInt(duration),
      maxPoints: parseInt(maxPoints),
      downsample: parseInt(downsample),
      model,
    });
    
    if (!result.success || result.pointCount === 0) {
      return res.status(404).json({
        success: false,
        error: 'No point cloud data received',
        lidarIp: ip,
        packetsReceived: result.packetsReceived || 0,
      });
    }
    
    // Return based on requested format
    if (format === 'binary') {
      const buffer = pointsToBuffer(result.points);
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('X-Point-Count', result.pointCount);
      res.setHeader('X-Lidar-IP', ip);
      return res.send(buffer);
    }
    
    if (format === 'ply') {
      const ply = pointsToPly(result.points);
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="pointcloud-${ip.replace(/\./g, '-')}.ply"`);
      return res.send(ply);
    }
    
    // Default: JSON with compact points
    res.json({
      success: true,
      lidarIp: ip,
      pointCount: result.pointCount,
      packetsReceived: result.packetsReceived,
      timestamp: Date.now(),
      points: result.points.flatMap(p => [
        Math.round(p.x * 1000) / 1000,
        Math.round(p.y * 1000) / 1000,
        Math.round(p.z * 1000) / 1000,
        p.intensity
      ]),
    });
  } catch (err) {
    console.error('[PointCloud] Snapshot error:', err.message);
    res.status(500).json({
      success: false,
      error: err.message,
      lidarIp: ip,
    });
  }
});

// ========== END POINT CLOUD STREAMING API ==========

// POST /api/edge/config/apply - Apply extrinsics configuration from main server
app.post('/api/edge/config/apply', (req, res) => {
  console.log('[Edge Commissioning] Config apply received');
  
  const extrinsicsPackage = req.body;
  
  if (!extrinsicsPackage || !extrinsicsPackage.deploymentId) {
    return res.status(400).json({ ok: false, error: 'Invalid extrinsics package' });
  }
  
  // Compute config hash for idempotency
  const sortedConfig = JSON.stringify(extrinsicsPackage, Object.keys(extrinsicsPackage).sort());
  const configHash = crypto.createHash('sha256').update(sortedConfig).digest('hex').substring(0, 16);
  
  // Check if already applied (idempotent)
  if (appliedConfigHash === configHash) {
    console.log(`[Edge Commissioning] Config already applied (hash: ${configHash})`);
    return res.json({
      ok: true,
      appliedConfigHash: configHash,
      message: 'Configuration already applied',
      alreadyApplied: true,
    });
  }
  
  // Apply the configuration
  try {
    // Update MQTT settings
    if (extrinsicsPackage.mqtt) {
      config.mqttBroker = extrinsicsPackage.mqtt.broker || config.mqttBroker;
      // Topic pattern is usually fixed per edge, but venueId can be updated
    }
    
    // Update venueId
    if (extrinsicsPackage.venueId) {
      config.venueId = extrinsicsPackage.venueId;
    }
    
    // Store the extrinsics for use by the fusion stack
    // In production, this would configure the actual LiDAR processing pipeline
    appliedConfig = extrinsicsPackage;
    appliedConfigHash = configHash;
    
    // Save updated config
    saveConfig();
    
    console.log(`[Edge Commissioning] Config applied successfully:`);
    console.log(`  - Deployment ID: ${extrinsicsPackage.deploymentId}`);
    console.log(`  - Venue ID: ${extrinsicsPackage.venueId}`);
    console.log(`  - LiDARs configured: ${extrinsicsPackage.lidars?.length || 0}`);
    console.log(`  - Config hash: ${configHash}`);
    
    // If simulation is running, reconnect MQTT with new settings
    if (isRunning && mqttClient) {
      console.log('[Edge Commissioning] Reconnecting MQTT with new settings...');
      mqttClient.end();
      mqttClient = mqtt.connect(config.mqttBroker);
      mqttClient.on('connect', () => {
        console.log('[Edge Commissioning] MQTT reconnected');
        stats.mqttConnected = true;
      });
      mqttClient.on('error', (err) => {
        console.error('[Edge Commissioning] MQTT error:', err.message);
        stats.lastError = err.message;
        stats.mqttConnected = false;
      });
    }
    
    res.json({
      ok: true,
      appliedConfigHash: configHash,
      message: 'Configuration applied successfully',
      lidarCount: extrinsicsPackage.lidars?.length || 0,
    });
  } catch (err) {
    console.error('[Edge Commissioning] Failed to apply config:', err.message);
    res.status(500).json({
      ok: false,
      error: 'Failed to apply configuration',
      message: err.message,
    });
  }
});

// GET /api/edge/status - Get edge status for commissioning portal
app.get('/api/edge/status', async (req, res) => {
  const uptime = stats.startTime ? Math.floor((Date.now() - stats.startTime) / 1000) : 0;
  
  // Build lidar connection statuses
  const lidarConnectionStatuses = {};
  for (const lidar of lidarInventory) {
    lidarConnectionStatuses[lidar.lidarId] = lidar.reachable;
  }
  
  // Get HER status if in HER mode
  let herStatus = null;
  if (isHerActive()) {
    try {
      herStatus = await getHerStatus();
    } catch (err) {
      console.error('[Status] Error getting HER status:', err.message);
    }
  }
  
  res.json({
    online: true,
    edgeId: config.deviceId,
    edgeVersion: '1.0.0',
    uptime,
    isRunning,
    appliedConfigHash,
    appliedVenueId: appliedConfig?.venueId || null,
    lidarConnectionStatuses,
    mqttConnected: stats.mqttConnected,
    mqttBroker: config.mqttBroker,
    tracksSent: stats.tracksSent,
    lastError: stats.lastError,
    // HER mode info
    operationalMode: getMode(),
    herStatus,
  });
});

// ========== END EDGE COMMISSIONING API ==========

// ========== HER (HYPERSPACE EDGE RUNTIME) API ==========

// Initialize HER Manager
initHerManager();

// POST /api/edge/her/deploy - Deploy HER with provider module
app.post('/api/edge/her/deploy', async (req, res) => {
  console.log('[HER API] Deploy request received');
  
  const payload = req.body;
  
  if (!payload || !payload.deployment || !payload.providerModule) {
    return res.status(400).json({
      ok: false,
      error: 'Invalid payload: requires deployment and providerModule',
    });
  }
  
  // Callback to stop simulator when HER starts
  const onSimulatorStop = () => {
    if (isRunning) {
      console.log('[HER API] Stopping simulator for HER deploy...');
      stopSimulation();
    }
  };
  
  try {
    const result = await deployHer(payload, onSimulatorStop);
    
    if (result.ok) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (err) {
    console.error('[HER API] Deploy error:', err.message);
    res.status(500).json({
      ok: false,
      error: 'HER deploy failed',
      message: err.message,
    });
  }
});

// GET /api/edge/her/status - Get HER status
app.get('/api/edge/her/status', async (req, res) => {
  try {
    const status = await getHerStatus();
    res.json(status);
  } catch (err) {
    console.error('[HER API] Status error:', err.message);
    res.status(500).json({
      ok: false,
      error: 'Failed to get HER status',
      message: err.message,
    });
  }
});

// POST /api/edge/her/stop - Stop HER and resume simulator
app.post('/api/edge/her/stop', async (req, res) => {
  console.log('[HER API] Stop request received');
  
  // Callback to resume simulator when HER stops
  const onSimulatorResume = async () => {
    console.log('[HER API] Resuming simulator after HER stop...');
    await startSimulation();
  };
  
  try {
    const result = await stopHer(onSimulatorResume);
    res.json(result);
  } catch (err) {
    console.error('[HER API] Stop error:', err.message);
    res.status(500).json({
      ok: false,
      error: 'Failed to stop HER',
      message: err.message,
    });
  }
});

// GET /api/edge/mode - Get current operational mode
app.get('/api/edge/mode', (req, res) => {
  res.json({
    mode: getMode(),
    isHerActive: isHerActive(),
  });
});

// ========== END HER API ==========

app.post('/api/start', async (req, res) => {
  const result = await startSimulation();
  res.json(result);
});

app.post('/api/stop', (req, res) => {
  console.log(`[API] POST /api/stop from ${req.ip} - stopping simulation`);
  const result = stopSimulation();
  res.json(result);
});

// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../frontend/dist/index.html'));
});

const PORT = process.env.PORT || 8080;
const WS_PORT = process.env.WS_PORT || 8081;

// Create HTTP server for Express
const server = http.createServer(app);

// Create WebSocket server for point cloud streaming
const wss = new WebSocketServer({ port: WS_PORT });

// Track active point cloud streams
const activeStreams = new Map();

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://localhost:${WS_PORT}`);
  const lidarIp = url.searchParams.get('ip') || '192.168.1.200';
  const model = url.searchParams.get('model') || 'RS16';
  const downsample = parseInt(url.searchParams.get('downsample') || '2');
  
  console.log(`[WebSocket] Client connected for LiDAR ${lidarIp}`);
  
  // Start point cloud stream for this client
  const stopStream = startPointCloudStream(lidarIp, (frame) => {
    if (ws.readyState === ws.OPEN) {
      try {
        // Send binary data for efficiency
        const buffer = pointsToBuffer(frame.points);
        ws.send(buffer, { binary: true });
      } catch (err) {
        console.error('[WebSocket] Send error:', err.message);
      }
    }
  }, {
    frameInterval: 100, // 10 FPS
    maxPointsPerFrame: 30000,
    downsample,
    model,
  });
  
  activeStreams.set(ws, { lidarIp, stopStream });
  
  ws.on('close', () => {
    console.log(`[WebSocket] Client disconnected for LiDAR ${lidarIp}`);
    const stream = activeStreams.get(ws);
    if (stream) {
      stream.stopStream();
      activeStreams.delete(ws);
    }
  });
  
  ws.on('error', (err) => {
    console.error(`[WebSocket] Error for LiDAR ${lidarIp}:`, err.message);
  });
  
  // Send initial metadata
  ws.send(JSON.stringify({
    type: 'metadata',
    lidarIp,
    model,
    downsample,
    frameInterval: 100,
  }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   🎯 Edge LiDAR Server                               ║
║                                                      ║
║   Web UI: http://localhost:${PORT}                     ║
║   API:    http://localhost:${PORT}/api                 ║
║   WebSocket: ws://localhost:${WS_PORT}                  ║
║                                                      ║
║   Endpoints:                                         ║
║   - GET  /api/config    Get configuration            ║
║   - POST /api/config    Update configuration         ║
║   - GET  /api/status    Get simulation status        ║
║   - POST /api/start     Start simulation             ║
║   - POST /api/stop      Stop simulation              ║
║   - WS   :${WS_PORT}/?ip=x.x.x.x  Point cloud stream    ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
  `);
});
