// Backup of original checkoutqueue.js
